# Identification handoff: identification_ID_NORMAL_002_trajectory_export_RUN_02_20261015T133850

raw/ holds unmodified recorder output; run_report/ is derived (see RUN_AUDIT.md);
context/ holds the trajectory, operator docs and change evidence.
Timestamps are host receive times; STATUS frames carry no device timestamp.

## Unavailable artifacts
- none
